//
//  ViewController.h
//  GettingStartProject
//
//  Created by Ratha Hin on 3/3/14.
//  Copyright (c) 2014 Ratha Hin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
